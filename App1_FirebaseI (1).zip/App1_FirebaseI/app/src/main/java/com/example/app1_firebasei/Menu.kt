package com.example.app1_firebasei

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Menu : AppCompatActivity() {

    private lateinit var lblBienvenida: TextView
    private lateinit var btnPerfil: Button
    private lateinit var btnManipular: Button
    private lateinit var btnCerrarSesion: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        lblBienvenida = findViewById(R.id.lblBienvenida)
        btnPerfil = findViewById(R.id.btnPerfil)
        btnManipular = findViewById(R.id.btnManipular)
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)

        val usuario = intent.getSerializableExtra("usuario", Usuario::class.java)

        if (usuario != null) {
            lblBienvenida.text = "Bienvenido, ${usuario.nombre}"
        }

        btnPerfil.setOnClickListener {
            val intent = Intent(this, Perfil::class.java)
            intent.putExtra("usuario", usuario)
            startActivity(intent)
        }

        btnManipular.setOnClickListener {
            val intent = Intent(this, ManipularESP32::class.java)
            startActivity(intent)
        }

        btnCerrarSesion.setOnClickListener {
            val intent = Intent(this, Principal::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}