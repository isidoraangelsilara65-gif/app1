package com.example.app1_firebasei

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ManipularESP32 : AppCompatActivity() {

    private lateinit var lblEstadoESP: TextView
    private lateinit var btnEncender: Button
    private lateinit var btnApagar: Button
    private lateinit var btnVolverESP: Button

    private lateinit var databaseRef: DatabaseReference
    private var valueEventListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manipular_esp32)

        lblEstadoESP = findViewById(R.id.lblEstadoESP)
        btnEncender = findViewById(R.id.btnEncender)
        btnApagar = findViewById(R.id.btnApagar)
        btnVolverESP = findViewById(R.id.btnVolverESP)

        databaseRef = FirebaseDatabase.getInstance("https://app1-firebasei-default-rtdb.firebaseio.com/").getReference("dispositivo")

        valueEventListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val nivelGas = snapshot.child("nivel_gas").getValue(Int::class.java) ?: 0
                val estadoValvula = snapshot.child("valvula").getValue(Int::class.java) ?: 0

                val estadoTexto = if (estadoValvula == 1) "Válvula Abierta" else "Válvula Cerrada"

                if (nivelGas > 400) {
                    lblEstadoESP.text = "¡ALERTA FUGA! Gas: $nivelGas PPM\n($estadoTexto)"
                    lblEstadoESP.setTextColor(Color.RED)
                } else {
                    lblEstadoESP.text = "Estado Seguro: $nivelGas PPM\n($estadoTexto)"
                    lblEstadoESP.setTextColor(Color.parseColor("#008000"))
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Error al leer datos: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        }
        valueEventListener?.let { databaseRef.addValueEventListener(it) }

        btnEncender.setOnClickListener {
            databaseRef.child("valvula").setValue(1)
                .addOnSuccessListener {
                    Toast.makeText(this, "Comando enviado: Válvula Abierta", Toast.LENGTH_SHORT).show()
                }
        }

        btnApagar.setOnClickListener {
            databaseRef.child("valvula").setValue(0)
                .addOnSuccessListener {
                    Toast.makeText(this, "Corte de emergencia aplicado", Toast.LENGTH_SHORT).show()
                }
        }

        btnVolverESP.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        valueEventListener?.let { databaseRef.removeEventListener(it) }
    }
}