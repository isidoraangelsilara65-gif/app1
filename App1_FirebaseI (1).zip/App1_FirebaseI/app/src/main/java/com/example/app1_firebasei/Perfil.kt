package com.example.app1_firebasei

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Perfil : AppCompatActivity() {

    private lateinit var txtNombrePerfil: TextView
    private lateinit var txtEmailPerfil: TextView
    private lateinit var txtTipoPerfil: TextView
    private lateinit var btnVolverPerfil: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        txtNombrePerfil = findViewById(R.id.txtNombrePerfil)
        txtEmailPerfil = findViewById(R.id.txtEmailPerfil)
        txtTipoPerfil = findViewById(R.id.txtTipoPerfil)
        btnVolverPerfil = findViewById(R.id.btnVolverPerfil)


        val usuario = intent.getSerializableExtra("usuario", Usuario::class.java)

        if (usuario != null) {
            txtNombrePerfil.text = "Nombre: ${usuario.nombre}"
            txtEmailPerfil.text = "Correo: ${usuario.email}"
            txtTipoPerfil.text = "Tipo de usuario: ${usuario.tipo}"
        }

        btnVolverPerfil.setOnClickListener {
            finish()
        }
    }
}