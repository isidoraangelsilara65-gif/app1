package com.example.app1_firebasei

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Principal : AppCompatActivity() {

    private lateinit var txtEmail: EditText
    private lateinit var txtPass: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        txtEmail = findViewById(R.id.txtEmail)
        txtPass = findViewById(R.id.txtPass)
        btnLogin = findViewById(R.id.btnLogin)

        val databaseRef = FirebaseDatabase.getInstance("https://app1-firebasei-default-rtdb.firebaseio.com/").getReference("usuarios")

        btnLogin.setOnClickListener {
            val emailInput = txtEmail.text.toString().trim()
            val passInput = txtPass.text.toString().trim()

            if (emailInput.isEmpty() || passInput.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            databaseRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var usuarioEncontrado: Usuario? = null

                    for (userSnapshot in snapshot.children) {
                        val u: Usuario? = userSnapshot.getValue(Usuario::class.java)
                        if (u != null && u.email.equals(emailInput, ignoreCase = true) && u.contrasena.toString() == passInput) {
                            usuarioEncontrado = u
                            break
                        }
                    }

                    if (usuarioEncontrado != null) {
                        Toast.makeText(applicationContext, "Bienvenido ${usuarioEncontrado.nombre}", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@Principal, Menu::class.java)
                        intent.putExtra("usuario", usuarioEncontrado)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(applicationContext, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(applicationContext, "Error de red: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}