package com.example.app1_firebasei

import com.google.firebase.database.PropertyName
import java.io.Serializable

data class Usuario(
    var nombre: String = "",
    var email: String = "",
    var tipo: String = "",
    @get:PropertyName("contraseña")
    @set:PropertyName("contraseña")
    @field:PropertyName("contraseña")
    var contrasena: Any = ""
) : Serializable